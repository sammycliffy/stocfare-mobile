plugins {
    `java-library`
}

dependencies {
    implementation(project(":list"))
}