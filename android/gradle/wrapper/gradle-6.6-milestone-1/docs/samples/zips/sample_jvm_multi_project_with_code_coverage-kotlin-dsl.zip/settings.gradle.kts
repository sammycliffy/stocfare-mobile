rootProject.name = "jvm-multi-project-with-code-coverage"
include("application", "list", "utilities")
