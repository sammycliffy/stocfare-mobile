plugins {
    groovy
}

dependencies {
    implementation("org.codehaus.groovy:groovy-all:2.5.11")
    implementation(project(":list"))
}
