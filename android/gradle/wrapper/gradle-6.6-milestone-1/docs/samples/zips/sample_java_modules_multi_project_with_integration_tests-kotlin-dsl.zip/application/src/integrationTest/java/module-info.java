open module org.gradle.sample.integtest.app {
    requires org.gradle.sample.app;
    requires org.junit.jupiter.api;
}
