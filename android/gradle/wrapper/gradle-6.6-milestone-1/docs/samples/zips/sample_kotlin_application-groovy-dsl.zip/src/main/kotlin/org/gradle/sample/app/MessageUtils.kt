package org.gradle.sample.app

class MessageUtils {
    companion object {
        fun getMessage(): String = "Hello,      World!"
    }
}
