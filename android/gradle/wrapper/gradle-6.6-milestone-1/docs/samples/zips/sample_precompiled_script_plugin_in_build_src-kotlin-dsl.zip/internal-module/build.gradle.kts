plugins {
    id("com.example.java-convention")
}

dependencies {
    // internal module dependencies
}
