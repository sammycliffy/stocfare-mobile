// Needs to be used with --settings-file settings-composite.gradle.kts

rootProject.name = "my-app"

includeBuild("../my-utils")
