rootProject.name = "number-utils"
