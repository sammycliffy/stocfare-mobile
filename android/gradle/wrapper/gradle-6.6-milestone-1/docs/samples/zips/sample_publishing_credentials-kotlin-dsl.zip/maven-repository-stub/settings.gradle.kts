rootProject.name = "maven-repository-stub"
