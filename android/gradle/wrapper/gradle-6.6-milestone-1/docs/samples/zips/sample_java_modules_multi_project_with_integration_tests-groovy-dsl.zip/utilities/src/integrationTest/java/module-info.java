open module org.gradle.sample.integtest.utilities {
    requires org.gradle.sample.utilities;
    requires org.junit.jupiter.api;
}
