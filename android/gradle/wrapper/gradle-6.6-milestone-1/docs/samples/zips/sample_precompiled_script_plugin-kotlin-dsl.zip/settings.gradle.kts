rootProject.name = "consumer-service"

includeBuild("plugin")
