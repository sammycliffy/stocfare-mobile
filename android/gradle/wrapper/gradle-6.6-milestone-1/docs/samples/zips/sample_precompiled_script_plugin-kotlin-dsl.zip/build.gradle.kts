plugins {
    id("com.example.service") version "1.0"
}
