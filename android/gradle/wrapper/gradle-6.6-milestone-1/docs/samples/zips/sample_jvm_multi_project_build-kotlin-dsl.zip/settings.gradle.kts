rootProject.name = "transitive-dependencies"
include("application", "list", "utilities")
