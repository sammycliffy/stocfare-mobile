plugins {
    `java-library`
}

dependencies {
    api(project(":list"))
}
