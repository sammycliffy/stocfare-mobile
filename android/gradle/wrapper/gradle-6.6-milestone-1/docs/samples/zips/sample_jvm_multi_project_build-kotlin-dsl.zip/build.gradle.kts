allprojects {
    group = "org.gradle.sample"
    version = "1.2"
}
