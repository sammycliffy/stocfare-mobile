rootProject.name = "spring-boot-demo"
