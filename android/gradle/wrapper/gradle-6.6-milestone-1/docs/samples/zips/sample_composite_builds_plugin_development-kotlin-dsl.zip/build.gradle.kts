plugins {
    id("org.sample.greeting").version("1.0-SNAPSHOT")
}

greeting {
    who = "Bob"
}
