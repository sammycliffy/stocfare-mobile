rootProject.name = "consumer"

// To function outside a composite, a plugin repository would be required here
