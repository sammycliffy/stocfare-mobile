plugins {
    application
}

version = "1.0.2"
group = "org.gradle.sample"

application {
    mainClass.set("org.gradle.sample.app.Main")
}
