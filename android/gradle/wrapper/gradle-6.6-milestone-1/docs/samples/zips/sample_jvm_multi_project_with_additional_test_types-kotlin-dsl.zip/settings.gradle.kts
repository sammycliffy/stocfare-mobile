rootProject.name = "multi-project-with-additional-test-types"
include("application", "list", "utilities")
