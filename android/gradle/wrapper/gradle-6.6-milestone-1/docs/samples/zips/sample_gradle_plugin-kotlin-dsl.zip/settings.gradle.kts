
rootProject.name = "gradle-plugin-in-java"
