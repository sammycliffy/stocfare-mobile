rootProject.name = "multi-project-with-spock-tests"
include("application", "list", "utilities")
