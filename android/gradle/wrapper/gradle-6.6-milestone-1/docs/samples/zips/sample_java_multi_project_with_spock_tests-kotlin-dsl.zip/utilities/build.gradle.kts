plugins {
    `java-library`
    `groovy-base`
}

dependencies {
    api(project(":list"))
}
