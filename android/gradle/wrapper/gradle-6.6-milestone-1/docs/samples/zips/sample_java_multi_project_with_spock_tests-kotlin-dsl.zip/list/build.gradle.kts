plugins {
    `java-library`
    `groovy-base`
}

dependencies {
    testImplementation("org.codehaus.groovy:groovy-all:2.5.11")
    testImplementation("org.spockframework:spock-core:1.3-groovy-2.5")
}
