rootProject.name = "library-publishing"
