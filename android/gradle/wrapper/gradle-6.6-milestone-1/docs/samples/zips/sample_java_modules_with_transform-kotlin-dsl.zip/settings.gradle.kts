rootProject.name = "modules-with-transform"
include("application")
